

import java.awt.*;
import javax.swing.*;
import java.util.Random;
import java.awt.event.*;
import java.util.Scanner;

public class Assignment5Driver 
{
	private static DataController dcontrol = new DataController();
	
	public static void main (String[] args)
	{
		MainMenuPanel mmp = new MainMenuPanel();
		
		
		//frame.dispose();
	}
	
	
}


/***********************************************
Where are the use case controller classes?  I am
assuming that your DataController class is the boundary
class to the persistent storage.  If so, 
You have the UI communicating directly with the
student information boundary class.

Why did you change the model?

18/50

***********************************************/