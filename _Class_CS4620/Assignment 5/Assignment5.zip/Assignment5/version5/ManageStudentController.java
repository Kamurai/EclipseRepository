package version5;

import java.awt.*;
import javax.swing.*;

import java.util.Random;
import java.awt.event.*;
import java.util.ArrayList;

public class ManageStudentController
{
	
		
	public ManageStudentController()
	{
		
	}
	
	public static void UpdateStudent (ArrayList<JTextField> inputlist, int index)
	{
		ArrayList<String> CI = new ArrayList<String>();
		
		for(int x = 0; x < inputlist.size(); x++ )
		{
			CI.add(inputlist.get(x).getText());
		}
		
		studentInfoManager.updateCareerInterests(index, CI);
		
	}

	
	public static void ViewStudent (JFrame frame, JPanel CenterPanel, ArrayList<JButton> buttonlist, ArrayList<JTextField> inputlist, JTextArea Output2, ActionEvent event )
	{
		//check which button was pressed
		for(int x = 0; x < studentInfoManager.getSize(); x++)
		{
			//if source is identified
			if( event.getSource() == buttonlist.get(x) )
			{
				//load the appropriate information
				Output2.setText(studentInfoManager.getStudent(x).getStudentName());
				
				ArrayList<String> CI = new ArrayList<String>(studentInfoManager.getStudent(x).getCareerInterests());
				
				CenterPanel.setLayout(new GridLayout(CI.size(), 1));
				CenterPanel.removeAll();
				inputlist.clear();
				for(int y = 0; y < CI.size(); y++)
				{
					inputlist.add(new JTextField( CI.get(y)));
					CenterPanel.add(inputlist.get(y));			
					
				}
					
				
					
				//escape
				x = studentInfoManager.getSize();
			}
			
				
		}
	}
		

	
	
	
	public static void LoadMainMenu()
  	{
		//create the UI for the Main Menu
		MainMenu_Controller mmp = new MainMenu_Controller();
	}
		
	
	
}
