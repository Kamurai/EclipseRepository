package version5;

import java.awt.*;
import javax.swing.*;
import java.util.Random;
import java.awt.event.*;
import java.util.Scanner;

public class Assignment5Driver 
{
	private static studentInfoManager dcontrol = new studentInfoManager();
	
	public static void main (String[] args)
	{
		MainMenu_Controller mmp = new MainMenu_Controller();
	}
	
	
}


/***********************************************
Where are the use case controller classes?  I am
assuming that your DataController class is the boundary
class to the persistent storage.  If so, 
You have the UI communicating directly with the
student information boundary class.

Why did you change the model?

18/50

***********************************************/