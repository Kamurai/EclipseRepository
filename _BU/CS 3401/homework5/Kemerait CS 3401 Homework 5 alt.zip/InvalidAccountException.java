//Kemerait, Christopher
//CS 3401
//Homework 3

package homework5;

public class InvalidAccountException extends Exception
{
	InvalidAccountException(String message)
	{
		super (message);
	}

}
