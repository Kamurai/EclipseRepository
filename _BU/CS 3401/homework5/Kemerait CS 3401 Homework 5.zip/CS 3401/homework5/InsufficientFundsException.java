package homework5;
 

public class InsufficientFundsException extends Exception
{
	InsufficientFundsException(String message)
	{
		super (message);
	}
}
	

	


