package homework10;

import tester.Tester;

public class QuickSortTester
{
	public static void main(String[] args) 
	{
		Tester.run(new QuickSortTester());
	}

	// /////////////////////////////////////////////////////////////////
	// Create test methods here
	// /////////////////////////////////////////////////////////////////
	public void testBook(Tester t) 
	{
		try 
		{
			String[] Tim = {"Charlie", "Hotel", "Golf", "Whiskey", "Mike", "Romeo", "Zulu", "Alpha", "Bravo", "November"};
		
			String[] Bob = {"Zulu", "Whiskey", "Romeo", "November", "Mike", "Hotel", "Golf", "Charlie", "Bravo", "Alpha"};
			
			String[] Bill = {"Alpha", "Bravo", "Charlie", "Golf", "Hotel", "Mike", "November", "Romeo", "Whiskey", "Zulu"};
			
			
			QuickSort.quickSort(Tim);
			//test 1	See if QuickSorted array is the same as known sorted array
			t.checkExpect(Tim, Bill);
			
			//test 2	See if ordered reports a QuickSorted array as in ascending order
			t.checkExpect(QuickSort.ordered(Tim), true);
			
			//test 3	See if ordered t/f reports a known sorted array as in ascending order
			t.checkExpect(QuickSort.ordered(Bill, true), true);
					
			//test 4	See if ordered t/f reports a QuickSorted array as in ascending order
			t.checkExpect(QuickSort.ordered(Tim, true), true);
			
			//test 5	See if ordered t/f reports a QuickSorted array as not in descending order
			t.checkExpect(QuickSort.ordered(Tim, false), false);
			
			//test 6	See if ordered t/f reports a known descending order array as in descending order
			t.checkExpect(QuickSort.ordered(Bob, false), true);
			
			//test 7	See if ordered t/f reports a known descending order array as not in ascending order
			t.checkExpect(QuickSort.ordered(Bob, true), false);
			
					
			}
		// Come here for any unexpected Exceptions
		catch (Exception e) 
		{
			e.printStackTrace();
			t.fail();
		}
		
			
	}
	
}
