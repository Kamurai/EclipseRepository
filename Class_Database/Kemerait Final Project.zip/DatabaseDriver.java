//Kemerait, Christopher
//Database Project: Bloodbowl Option
//Database Driver

import java.awt.*;
import javax.swing.JFrame;
import javax.swing.*;
import java.util.Random;
import java.awt.event.*;
import java.util.Scanner;
import java.sql.*;
import java.io.*;


public class DatabaseDriver
{
  public static void main (String[] args)throws SQLException, IOException {
  		//Set Frame
      JFrame frame = new JFrame ("DatabaseDriver");
      frame.setDefaultCloseOperation (JFrame.EXIT_ON_CLOSE);
		
		//Add Panel
		frame.getContentPane().add( new DatabasePanel() );
		
		//End frame
      frame.pack();
      frame.setVisible(true);
   }
	
}


