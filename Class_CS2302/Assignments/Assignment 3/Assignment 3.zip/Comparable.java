//Kemerait, Christopher
//CSIS 2302
//Rational Number / Comaparable interface Assignment

//import java.lang;
import java.util.*;


public interface Comparable
{
	public int compareTo(RationalNumber bob);
	
}
