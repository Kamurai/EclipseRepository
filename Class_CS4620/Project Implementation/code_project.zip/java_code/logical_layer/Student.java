package logical_layer;
/**
 * 
 */

/** 
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 * @author dgayler
 */
public class Student 
{
	/** 
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * 
	 * @generated "UML to Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	private Profile profile;

	private String name;
	
	public Student(String name, String studentNum)
	{
		this.name = name;
		profile = new Profile();
	}

	/** 
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the profile
	 * @generated "UML to Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	public Profile getProfile()
	{
		// begin-user-code
		return profile;
		// end-user-code
	}

	/** 
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param theProfile the profile to set
	 * @generated "UML to Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	public void setProfile(Profile theProfile)
	{
		// begin-user-code
		profile = theProfile;
		// end-user-code
	}

	/**
	 * @return the name
	 */
	public String getName()
	{
		return name;
	}

	/**
	 * @param name the name to set
	 */
	public void setName(String name)
	{
		this.name = name;
	}
	
}