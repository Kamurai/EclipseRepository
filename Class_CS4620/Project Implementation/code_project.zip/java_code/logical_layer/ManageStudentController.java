/**
 * 
 */
package logical_layer;


/** 
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 * @author dgayler
 */
public class ManageStudentController
{
	/** 
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 */
	private StudentInfoManager manager;

	
	public ManageStudentController(StudentInfoManager manager)
	{
		this.manager = manager;
	}

	/** 
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param id
	 * @return
	 * @generated "UML to Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	public Student getStudent(String id)
	{
		// begin-user-code
		return manager.getStudent(id);
		// end-user-code
	}

	/** 
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param s
	 * @return
	 * @generated "UML to Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	public Boolean saveStudent(Student s)
	{
		// begin-user-code
		boolean valid = validateStudent (s);
		if (valid)
			manager.storeStudent(s);
		return valid;
		// end-user-code
	}

	/** 
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param s
	 * @return
	 * @generated "UML to Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	private Boolean validateStudent(Student s)
	{
		// begin-user-code
		// TODO Auto-generated method stub
		return true;
		// end-user-code
	}
}