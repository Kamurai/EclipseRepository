package logical_layer;
/**
 * 
 */

/** 
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 * @author dgayler
 */
public class Profile
{
	/** 
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 */
	private CareerInterests interests;

	public Profile ()
	{
		interests = new CareerInterests();
	}
	
	public Profile(CareerInterests interests)
	{
		this.interests = interests;
	}

	/**
	 * @return the interests
	 */
	public CareerInterests getInterests()
	{
		return interests;
	}

	/**
	 * @param interests the interests to set
	 */
	public void setInterests(CareerInterests interests)
	{
		this.interests = interests;
	}
}