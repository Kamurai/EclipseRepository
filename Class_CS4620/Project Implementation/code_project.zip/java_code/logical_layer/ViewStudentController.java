/**
 * 
 */
package logical_layer;

/** 
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 * @author dgayler
 */
public class ViewStudentController
{
	/** 
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 */
	private StudentInfoManager manager;

	
	public ViewStudentController(StudentInfoManager manager)
	{
		this.manager = manager;
	}

	/** 
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return
	 * @generated "UML to Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	public StudentNameCollection getStudentNames()
	{
		// begin-user-code
		return manager.getAllStudentNames();
		// end-user-code
	}

	/** 
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param s
	 * @return
	 * @generated "UML to Java (com.ibm.xtools.transform.uml2.java5.internal.UML2JavaTransform)"
	 */
	public Student getStudent(String stuNum)
	{
		// begin-user-code
		return manager.getStudent(stuNum);
		// end-user-code
	}
}