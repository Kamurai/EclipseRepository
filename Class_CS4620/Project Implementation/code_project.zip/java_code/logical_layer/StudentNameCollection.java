/**
 * 
 */
package logical_layer;

import java.util.ArrayList;
import java.util.List;

/** 
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 * @author dgayler
 */
public class StudentNameCollection
{
	private List<String> names;
	
	public StudentNameCollection()
	{
		names = new ArrayList<String>();
	}

	/**
	 * @return the names
	 */
	public List<String> getNames()
	{
		return names;
	}
	
	public void addName (String name)
	{
		names.add(name);
	}
}