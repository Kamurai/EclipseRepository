package startup;

import javax.swing.JFrame;

import ui.MainWindow;

import logical_layer.StudentInfoManager;

public class Main
{

	public static void main(String[] args)
	{
		StudentInfoManager manager = new StudentInfoManager();
		JFrame startUpWin = new MainWindow (manager);
		startUpWin.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}

}
